/**
 * @author Zotya
 * Allomas es UtasKocsi szinenek ertekei lehetnek
 * megadtam parat, ennyi eleg lesz
 * lehet boviteni ha kell
 */
public enum Szin {
	PIROS,
	ZOLD,
	KEK,
	SARGA
	
}