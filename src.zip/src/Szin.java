
public enum Szin {
	PIROS,
	ZOLD,
	KEK,
	SARGA
	//eleg lesz sztem
	//Allomas skeletonja ezeket hasznalja
}

//Zotya