
public enum AlagutAllapot {
	NincsAlagutSzaj, EgyAlagutSzaj, VanAlagut
}
